# api-gateway (SHOULD BE INSIDE SPRING-BOOT-WRAPPER)
This Application used to display how Spring Zuul Proxy works with the help of Spring Boot Eureka Server. 
This application can be used along with Discovery Server and Application.

1- https://github.com/JBTAdmin/Spring-Boot/
2- https://github.com/JBTAdmin/discovery-server
