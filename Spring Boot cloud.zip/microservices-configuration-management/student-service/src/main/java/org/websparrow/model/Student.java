package org.websparrow.model;

public class Student {

	private Integer records;

	public Integer getRecords() {
		return records;
	}

	public Student(Integer records) {
		super();
		this.records = records;
	}

	public Student() {
		super();
	}
}
